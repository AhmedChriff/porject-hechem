 <html>
 <body>
 
 
 <!-- === BEGIN FOOTER === -->
            <div id="base">
                <div class="container bottom-border padding-vert-30">
                    <div class="row">
                        <!-- Disclaimer -->
                        <div class="col-md-4">
                            <h3 class="class margin-bottom-10"><b>Anand Map</b></h3>
                            
							   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117913.86177120777!2d72.87469370425329!3d22.548857238604224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e4e7efd0c8885%3A0xa9a0b93c0c4b5215!2sAnand%2C+Gujarat!5e0!3m2!1sen!2sin!4v1490351905043" width="260" height="230" frameborder="0" style="border:0" allowfullscreen></iframe>
						</div>
                        <!-- End Disclaimer -->
                        <!-- Contact Details -->
                        <div class="col-md-4 margin-bottom-20">
                              <h3 class="margin-bottom-20"><b>Contact Details</b></h3>
							  <div class="margin-bottom-10">
							  <font size="3"><b>District Emergency Response Center</b></font>
                              </div>
                            <p>
                                <span class="fa-phone">Telephone : </span>+91 2692 243222
                            <br><br>
							<div class="margin-bottom-10">
							  <font size="3"><b>Commissioner of Rescue &amp; Relief</b></font>
                              </div>
                            <p>
                                <span class="fa-phone">Telephone : </span>1070
									
									
			</div>
                        <!-- End Contact Details -->
                        <!-- Sample Menu -->
                        <div class="col-md-4 margin-bottom-20">
                            <h3 class="margin-bottom-10"><b>Site Map</b></h3>
                            <ul class="menu">
                                <li>
                                    <a class="fa-tasks" href="about_us.php">About Us</a>
                                </li>
                                <li>
                                    <a class="fa-users" href="janseva.php">Jan Seva Kendra</a>
                                </li>
                                <li>
                                    <a class="fa-signal" href="branch.php">Branches</a>
                                </li>
                                <li>
                                    <a class="fa-coffee" href="atvt.php">Programs</a>
                                </li>
								<li>
                                    <a class="fa-tasks" href="aboutanand.php">About Anand</a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <!-- End Sample Menu -->
                    </div>
                </div>
            </div>
           
            <!-- JS -->

			
</body>
</html>