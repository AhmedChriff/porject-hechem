 <html>
 <body>
 
 
 <h1 style="color:darkred;">Branches</h1>
									 <br>
									
                            <ul class="list-group sidebar-nav" id="sidebar-nav">
                               
                                      
                                <li class="list-group-item">
                                    <a href="branch.php">Administration</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="b_supply.php">Supply</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="b_entertainment.php">Entertainment</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="b_village.php">Village Panchayat Election</a>
                                </li>
                                
                                <li class="list-group-item">
                                    <a href="b_account.php">Accounts</a>
                                </li>
                               
                                <li class="list-group-item">
                                    <a href="b_municipality.php">Municipality</a>
                                </li>
								
								<li class="list-group-item">
                                    <a href="b_establishment.php">Establishment</a>
                                </li>
                                
                            </ul>
									
									
								<br>	

			
</body>
</html>