
<!DOCTYPE html>
<html>
<head>
<title>Tulip Polymers</title>
<!--/tags -->
<meta name="google-site-verification" content="lT1ZoT_ZQ2rD9kY67SXPWMv_gq90F7QR9ISq2Rgi2oQ" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Elite Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--//tags -->
<script type="text/javascript" src="http://tulippoly.com/template/sections/js/jquery-2.1.4.min.js"></script>
<link href="http://tulippoly.com/template/sections/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://tulippoly.com/template/sections/css/team.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://tulippoly.com/template/sections/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://tulippoly.com/template/sections/css/font-awesome.css" rel="stylesheet"> 
<!-- //for bootstrap working -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-109307649-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-109307649-1');
</script>

</head>
<body style="background:#fffaf0;">
<!-- header -->
<div class="header" id="home" style="background:#7f2726;">
	<div class="container">
		<!--<ul>
		    
			<li><i class="fa fa-phone" aria-hidden="true" style="color:#f58634;"></i> Call : 01234567898</li>
			<li><i class="fa fa-envelope-o" aria-hidden="true" style="color:#f58634;"></i> <a href="mailto:info@example.com">info@example.com</a></li>
		</ul>-->
	</div>
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="header-bot_inner_wthreeinfo_header_mid">
		
		<!-- header-bot -->
			<div class="col-md-2 col-sm-2 logo_agile">
				<img src="http://tulippoly.com/template/sections/images/logo1.png" style="height:70px;width:100%;">
			</div>
			
			<div class="col-md-6 header-middle">
			
		</div>
        <!-- header-bot -->
		<div class="col-md-4 agileits-social top_content">
						<ul class="social-nav model-3d-0 footer-social w3_agile_social">
						
						
						
						                                   <li class="share">Share On : </li>
															<li><a href="https://www.facebook.com/tulippolymers21" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
														<!--	<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>-->
															<li><a href="https://www.linkedin.com/company/13463598" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>



		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top" style="background-color:#7f2726;">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="index.php?action=index">Home <span class="sr-only">(current)</span></a></li>
					<li class=" menu__item"><a class="menu__link" href="index.php?action=about">About</a></li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Product <span class="caret"></span></a>
							<ul class="dropdown-menu multi-column columns-3">
								<div class="agile_inner_drop_nav_info">
									<div class="col-sm-6 multi-gd-img1 multi-gd-text ">
										<a href="index.php?action=mens"><img src="http://tulippoly.com/template/sections/images/Home-pvc.jpg" alt=" " style="height:236px;"/></a>
									</div>
									<div class="col-sm-3 multi-gd-img">
										<ul class="multi-column-dropdown">
											<li><a href="index.php?action=pvc">PVC</a></li>
											<li><a href="index.php?action=hdpe">HDPE</a></li>
											<li><a href="index.php?action=lldp">LDPE</a></li>
											<li><a href="index.php?action=polypropylene">POLYPROPYLENE</a></li>
											<li><a href="index.php?action=raw_material">RAW MATERIAL</a></li>
											<li><a href="index.php?action=molding">MOLDING</a></li>
											<li><a href="index.php?action=extrusion">EXTRUSION PROCESS</a></li>
										</ul>
									</div>
									
									<div class="clearfix"></div>
								</div>
							</ul>
					</li>
					
					<li class=" menu__item"><a class="menu__link" href="index.php?action=certificate">Certificate</a></li>
					
					<li class=" menu__item"><a class="menu__link" href="index.php?action=contact">Contact</a></li>
					<li class=" menu__item"><a class="menu__link" ><div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
		<div class="top_nav_right">
			<div class="wthreecartaits wthreecartaits2 cart cart box_1" style="background-color:#363435;"> 
						<form action="#" method="post" class="last"> 
						<!--<input type="hidden" name="cmd" value="_cart">
						<input type="hidden" name="display" value="1">-->
						<a class="w3view-cart" style="background-color:#363435;font-size: 30px;" href="Tulip_corporate_profile.pdf" target="_blank" value=""><i class="fa fa-cloud-download" style="color:#fff;" aria-hidden="true"></i></a>
					</form>  
  
						</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>

<style>
   .hvr-outline-out {
    
    background: #f58634;
}

.hvr-outline-out:before {
   
    border: #f58634 solid 4px;
   
}

.menu--shylock .menu__link::before {
    background: #f58634;
   
}

.menu--shylock .menu__link::after {
    background: #f58634;
}
ul.w3_short li a {
    color: #f58634;
    
}
.agile_ab_w3ls_info p {
    margin: 1em 0 0;
   
}
.header-bot {
    padding: 11px 0;
}

</style><div id="myCarousel" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1" class=""></li>
			<li data-target="#myCarousel" data-slide-to="2" class=""></li>
			
		</ol>
		<div class="carousel-inner" role="listbox">
			<div class="item active"> 
				<div class="container">
					<div class="carousel-caption">
						
					</div>
				</div>
			</div>
			<div class="item item2"> 
				<div class="container">
					<div class="carousel-caption">
						
					</div>
				</div>
			</div>
			<div class="item item3"> 
				<div class="container">
					<div class="carousel-caption">
						
					</div>
				</div>
			</div>
			
			
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
		<!-- The Modal -->
    </div> 
	<!-- //banner -->
    <div class="banner_bottom_agile_info">
	    
            <div class="schedule-bottom" style="background:#f58634;">
		<div class="col-md-6 agileinfo_schedule_bottom_left">
			<img src="http://tulippoly.com/template/sections/images/TULIP.jpg" alt=" " class="img-responsive" />
		</div>
		<div class="col-md-6 agileits_schedule_bottom_right" style="background:#f58634;">
			<div class="w3ls_schedule_bottom_right_grid" style="box-shadow: 5px 0px 10px #98bbc1;">
				<h3>About</h3>
				<p>Tulip Polymers was established in the year 2017 at Rajkot Gujarat. The Company is valued among our client for exporting, Importing, supplying of quality products in the globe, mainly in the field of polymers; sourced from globally acclaimed manufacturers. The product range consists of PVC, cPVC, HDPE, PP, LDPE and other Engineering Polymer�s Extruded and Moulded Products as well as Raw Materials.
<a href="index.php?action=about">Read more</a>				
</p>
				
				<!--<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-user-o" aria-hidden="true" style="color:#0098db"></i>
					<h4>Customers</h4>
					<h5 class="counter">653</h5>
				</div>
				<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-calendar-o" aria-hidden="true" style="color:#0098db"></i>
					<h4>Events</h4>
					<h5 class="counter">823</h5>
				</div>
				<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-shield" aria-hidden="true" style="color:#0098db"></i>
					<h4>Awards</h4>
					<h5 class="counter">45</h5>
				</div>-->
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="clearfix"> </div>
	</div>
		 
   
	
  <!-- banner-bootom-w3-agileits -->
  
    
	
	<div class="container" style="margin-top:6%;">
		<h3 class="wthree_text_info" style="color:#7f2726;">Offer <span>Products</span></h3>
	
		<div class="col-md-5 bb-grids bb-left-agileits-w3layouts">
			<a href="index.php?action=hdpe">
			   <div class="bb-left-agileits-w3layouts-inner grid">
					<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/HDPE_@.jpg" alt=" " style="height:606px;" class="img-responsive" />
							<figcaption>
								
								
							</figcaption>			
						</figure>
			    </div>
			</a>
			
			<a href="index.php?action=lldp">
			
			  <div class="bb-middle-agileits-w3layouts forth grid">
					<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/LDPE_@.jpg" alt=" " style="height:606px;" class="img-responsive" />
							<figcaption>
								
								
							</figcaption>			
						</figure>
			    </div>
			</a>
		</div>
		<div class="col-md-7 bb-grids bb-middle-agileits-w3layouts" style="height:77.5em">
		      <a href="index.php?action=pvc">
		       <div class="bb-middle-agileits-w3layouts grid">
			           <figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/PVC.jpg" alt=" " class="img-responsive" style="height:402px"/>
							<figcaption>
								
								
							</figcaption>			
						</figure>
		        </div>
				</a>
				<a href="index.php?action=polypropylene">
		      <div class="bb-middle-agileits-w3layouts forth grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/5PP_@.jpg" alt=" " class="img-responsive" style="height:402px">
							<figcaption>
							
								
							</figcaption>		
						</figure>
					</div>
					</a>
					
					<a href="index.php?action=raw_material">
		       <div class="bb-middle-agileits-w3layouts forth grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/RAW1_695x402.jpg" alt=" " class="img-responsive" style="height:402px">
							<figcaption>
								
								
							</figcaption>		
						</figure>
					</div>
				</a>
		<div class="clearfix"></div>
	</div>
	</div>
	
	<div class="agile_last_double_sectionw3ls" style="margin-top:6%;">
            <div class="col-md-6 multi-gd-img multi-gd-text ">
					<a href="index.php?action=molding"><img src="http://tulippoly.com/template/sections/images/molding.png" alt=" "><h4 style="color:#333;"><!--<span style="color:#f58634;">P</span><b>lastic Molding</b>--></h4></a>
					
			</div>
			 <div class="col-md-6 multi-gd-img multi-gd-text ">
					<a href="index.php?action=extrusion"><img src="http://tulippoly.com/template/sections/images/Process1.jpg" alt=" "><h4 style="color:#333;"><!--<span style="color:#f58634;">E</span><b>trusion Process</b>--></h4></a>
			</div>
			<div class="clearfix"></div>
			
			<div class="" style="margin-top: 3%;">
	    
            <div class="banner_bottom_agile_info_inner_w3ls">
    	           <div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/box_straps.jpg" alt=" " class="img-responsive" />
							<figcaption>
								<h3><span>B</span>ox Straps</h3>
								
							</figcaption>			
						</figure>
					</div>
					 <div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/granules.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>G</span>ranules</h3>
								
							</figcaption>			
						</figure>
					</div>
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/hdpe_drum.png" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>H</span>DPE Drum</h3>
								
							</figcaption>			
						</figure>
					</div>
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/hdpe_pipe.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>H</span>DPE Pipe</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/hdpe_woven_bag.jpeg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>H</span>DPE Woven Bag</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/plasticware.png" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>P</span>lasticware</h3>
								
							</figcaption>			
						</figure>
					</div>
					<div class="clearfix"></div>
		    </div> 
		
    </div>
	
	
	
	<div class="" style="margin-top: 3%;">
	    
            <div class="banner_bottom_agile_info_inner_w3ls">
    	           
					 
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/pp_fabric_bag.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>PP</span>Fabric Bag</h3>
								
							</figcaption>			
						</figure>
					</div>
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/PVC_FITTINGSAbout-2.png" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>P</span>VC Fitting</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/pvc_pipe.jpeg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>P</span>VC Pipe</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/stretch_film.png" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>S</span>tretch Film</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/suction_hoses.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>S</span>uction Hoses Pipe</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/woven_bag.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>W</span>oven Bag</h3>
								
							</figcaption>			
						</figure>
					</div>
					
					
					<div class="clearfix"></div>
		    </div> 
		
    </div>
	
	<div class="" style="margin-top: 3%;">
	    
            <div class="banner_bottom_agile_info_inner_w3ls">
    	         
					<!--<div class="col-md-2 grid">
						<figure class="effect-roxy">
							<img src="http://tulippoly.com/template/sections/images/plasticware1.jpg" alt=" " class="img-responsive" style="height:229px;"/>
							<figcaption>
								<h3><span>P</span>VC Pipe</h3>
								
							</figcaption>			
						</figure>
					</div>-->
					
					<div class="clearfix"></div>
		    </div> 
		
    </div>
	   </div>


	   
    
	</div>
	
<!--/grids-->

<style>
<style>
   .hvr-outline-out {
    
    background: #f58634;
}

.hvr-outline-out:before {
   
    border: #f58634 solid 4px;
   
}
.multi-gd-text img {
    width: 100%;
    height: 440px;
}  

</style><div class="footer" style="background:#7f2726;">
	<div class="footer_agile_inner_info_w3l">
		
		<div class="col-md-12">
			<div class="sign-grds">
				<div class="col-md-4 sign-gd">
					<h4>Our <span>Information</span> </h4>
					<ul>
						
						<li><a href="index.php?action=index" style="color:white;">Home</a></li>
						<li><a href="index.php?action=about" style="color:white;">About</a></li>
						
						<!--<li><a href="certificate.html" style="color:white;">Certificate</a></li>-->
						<li><a href="index.php?action=contact" style="color:white;">Contact</a></li>
					
					</ul>
				</div>
				
				<div class="col-md-4 sign-gd-two">
					<h4>Our <span>Information</span></h4>
					<div class="w3-address">
						<div class="w3-address-grid" style="background:#363435;">
							<div class="w3-address-left">
								<i class="fa fa-phone" aria-hidden="true" style="color:#f58634;"></i>
							</div>
							<div class="w3-address-right">
								<h6>Phone Number</h6>
								<p style="color:#f58634;">+91 9825847774
</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid" style="background:#363435;">
							<div class="w3-address-left">
								<i class="fa fa-envelope" aria-hidden="true" style="color:#f58634;"></i>
							</div>
							<div class="w3-address-right">
								<h6>Email Address</h6>
								<p style="color:#f58634;">Email :<a href="mailto:export@tulippoly.com
" style="color:#f58634;"> export@tulippoly.com
</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid" style="background:#363435;">
							<div class="w3-address-left">
								<i class="fa fa-map-marker" aria-hidden="true" style="color:#f58634;"></i>
							</div>
							<div class="w3-address-right">
								<h6>Location</h6>
								<p style="color:#f58634;">212, Cosmo Complex, Nr. Mahila College Chowk, Rajkot - 360001. Gujarat - India. 
								
								</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				
				<div class="col-md-1 sign-gd flickr-post"></div>
				<div class="col-md-3 sign-gd flickr-post">
					<h4>C <span>ertificate</span></h4>
					<!--<ul>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t4.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="http://tulippoly.com/template/sections/images/t4.jpg" alt=" " class="img-responsive" /></a></li>
					</ul>-->
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>
			
		 <div class="agile_newsletter_footer">
		    <div class="col-sm-12 newsleft">
				  <p class="copy-right" style="color:#fff;">&copy 2017 Tulip. All rights reserved | Design by <a href="#">Bizz.Website Private Limited (OPC)</a></p>
			</div>
			
		<div class="clearfix"></div>
	</div>
	
	</div>
</div>
<!-- //footer -->

<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- js -->

<!-- //js -->	
	<!-- cart-js -->
	<script src="http://tulippoly.com/template/sections/js/minicart.min.js"></script>
<script>
	// Mini Cart
	paypal.minicart.render({
		action: '#'
	});

	if (~window.location.search.indexOf('reset=true')) {
		paypal.minicart.reset();
	}
</script>

	<!-- //cart-js --> 

<!-- stats -->
	<script src="http://tulippoly.com/template/sections/js/jquery.waypoints.min.js"></script>
	<script src="http://tulippoly.com/template/sections/js/jquery.countup.js"></script>
	<script>
		$('.counter').countUp();
	</script>
<!-- //stats -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="http://tulippoly.com/template/sections/js/move-top.js"></script>
<script type="text/javascript" src="http://tulippoly.com/template/sections/js/jquery.easing.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->

<!-- for bootstrap working -->
<script type="text/javascript" src="http://tulippoly.com/template/sections/js/bootstrap.js"></script>
</body>
</html>

<style>
   
p.copy-right {
   
    margin-top: 0px;
    
}
</style>